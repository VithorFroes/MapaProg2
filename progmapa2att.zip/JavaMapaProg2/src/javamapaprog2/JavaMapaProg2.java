
package javamapaprog2;

import javamapaprog2.telas.Telainicial;

public class JavaMapaProg2 {

 
    public static void main(String[] args) {
        Telainicial ti = new Telainicial();
        ti.setVisible(true);
    }
    
}
