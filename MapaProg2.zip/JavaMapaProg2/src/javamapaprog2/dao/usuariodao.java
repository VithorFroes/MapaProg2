
package javamapaprog2.dao;

import javamapaprog2.TelaUsuarios;


public class usuariodao {
    public void inserir(TelaUsuarios usuarios){
        System.out.println("iniciando cadastro no banco de dados");
        System.out.println("Usuario a ser cadastrado " + usuarios.getNome());
    }
    
}
